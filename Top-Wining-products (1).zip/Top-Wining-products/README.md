# Top-Wining-products (`yasirhasho.work.gd`)

Amazon-style Gulf e-commerce product ranking dashboard powered by GitHub Pages and GitHub Actions.

## Included Files
- `CNAME`: Custom domain configuration (`yasirhasho.work.gd`)
- `index.html`: Mobile + desktop responsive Amazon-style storefront
- `rank_gulf_winners.py`: Python ranking engine that scores raw products and exports JSON/CSV
- `gulf_top_100_winners.json` & `gulf_top_100_winners.csv`: Pre-generated top ranked Gulf products
- `raw/sample_products.json`: Starter raw product dataset across Amazon SA, Noon, Shein, and Trendyol
- `.github/workflows/auto_update_winners.yml`: Automated workflow running every 6 hours + manual trigger
